#!/usr/bin/env python3
"""Level-lock mix: music = 50% of voice gated RMS (-6 dB), SFX = 50% (peaks <= 0.7x voice peak).
Usage: python3 mix.py voice.mp3 music.wav sfx.wav   -> mix_raw.wav (48k mono)"""
import sys, subprocess, wave, numpy as np
SR = 48000
def load(p):
    raw = subprocess.run(["ffmpeg","-v","error","-i",p,"-ac","1","-ar",str(SR),"-f","f32le","-"],capture_output=True).stdout
    return np.frombuffer(raw, np.float32).copy()
def gated_rms(x, thr_db=-40):
    w = SR // 10; n = len(x) // w
    if n == 0: return float(np.sqrt(np.mean(x**2)) + 1e-12)
    r = np.sqrt(np.mean(x[:n*w].reshape(n, w)**2, axis=1))
    db = 20*np.log10(r + 1e-12); g = r[db > db.max() - 30]
    return float(np.sqrt(np.mean(g**2)) + 1e-12)
db = lambda a, b: 20*np.log10(a / b)
voice, music, sfx = (load(a) for a in sys.argv[1:4])
N = len(voice)
fit = lambda x: np.pad(x, (0, max(0, N - len(x))))[:N]
music, sfx = fit(music), fit(sfx)
rv = gated_rms(voice)
music *= 0.5 * rv / gated_rms(music)
if np.abs(sfx).max() > 0:
    sfx *= 0.5 * rv / gated_rms(sfx)
    cap = 0.7 * np.abs(voice).max()
    if np.abs(sfx).max() > cap: sfx *= cap / np.abs(sfx).max()
mix = voice + music + sfx
pk = np.abs(mix).max()
if pk > 0.98: mix *= 0.98 / pk
f = int(0.04*SR); mix[-f:] *= np.linspace(1, 0, f)
with wave.open("mix_raw.wav","wb") as w:
    w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
    w.writeframes((np.clip(mix,-1,1)*32767).astype(np.int16).tobytes())
print(f"voice rms {20*np.log10(rv):.1f} dBFS | music {db(gated_rms(music), rv):+.1f} dB vs voice | sfx {db(gated_rms(sfx), rv):+.1f} dB (peak {np.abs(sfx).max()/np.abs(voice).max():.2f}x voice peak)")
